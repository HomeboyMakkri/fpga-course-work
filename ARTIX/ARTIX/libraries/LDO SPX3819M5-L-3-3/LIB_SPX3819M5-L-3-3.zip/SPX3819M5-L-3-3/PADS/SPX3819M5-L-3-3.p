*PADS-LIBRARY-PART-TYPES-V9*

SPX3819M5-L-3-3 SOT95P280X145-5N I ANA 9 1 0 0 0
TIMESTAMP 2026.10.08.17.46.11
"Manufacturer_Name" MaxLinear, Inc.
"Manufacturer_Part_Number" SPX3819M5-L-3-3
"Mouser Part Number" 701-SPX3819M5-L-3-3
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/MaxLinear/SPX3819M5-L-3-3?qs=2Z08r0Wtf%2Fyl32mFDRYBCg%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" IC REG LINEAR 3.3V 500MA SOT23-5
"Datasheet Link" https://componentsearchengine.com/Datasheets/2/SPX3819M5-L-3-3.pdf
"Geometry.Height" 1.45mm
GATE 1 5 0
SPX3819M5-L-3-3
1 0 U VIN
2 0 U GND
3 0 U EN
4 0 U ADJ/BYP
5 0 U VOUT

*END*
*REMARK* SamacSys ECAD Model
10092610/2105927/2.50/5/3/Integrated Circuit
