*PADS-LIBRARY-PART-TYPES-V9*

HKC3225SX-25MHZ-26594-R4V1 HKC3225SX25MHZ26594R4V1 I OSC 9 1 0 0 0
TIMESTAMP 2026.10.09.11.23.24
"Manufacturer_Name" Hong Kong X’tals Limited
"Manufacturer_Part_Number" HKC3225SX-25MHZ-26594-R4V1
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" 3225 Ceramic SMD Crystals, 25 MHz
"Datasheet Link" https://cms.nacsemi.com/content/AuthDatasheets/HKCrystal/C7.pdf
"Geometry.Height" 0.8mm
GATE 1 4 0
HKC3225SX-25MHZ-26594-R4V1
1 0 U CRYSTAL_1
2 0 U GND_1
3 0 U CRYSTAL_2
4 0 U GND_2

*END*
*REMARK* SamacSys ECAD Model
19099320/2105927/2.50/4/3/Crystal or Oscillator
