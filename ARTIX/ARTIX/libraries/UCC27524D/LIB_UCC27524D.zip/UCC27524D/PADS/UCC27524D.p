*PADS-LIBRARY-PART-TYPES-V9*

UCC27524D SOIC127P600X175-8N I ANA 9 1 0 0 0
TIMESTAMP 2026.10.16.18.03.36
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" UCC27524D
"Mouser Part Number" 595-UCC27524D
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/UCC27524D?qs=iuXUNOC6nYfyi9ut48diIw%3D%3D
"Arrow Part Number" UCC27524D
"Arrow Price/Stock" https://www.arrow.com/en/products/ucc27524d/texas-instruments?region=europe
"Description" Texas Instruments UCC27524D Dual Low Side MOSFET Power Driver, 5A, 4.5  18 V 8-Pin, SOIC
"Datasheet Link" http://uk.rs-online.com/web/p/products/7620418
"Geometry.Height" 1.75mm
GATE 1 8 0
UCC27524D
1 0 U ENA
2 0 U INA
3 0 U GND
4 0 U INB
8 0 U ENB
7 0 U OUTA
6 0 U VDD
5 0 U OUTB

*END*
*REMARK* SamacSys ECAD Model
306478/2105927/2.50/8/3/Integrated Circuit
